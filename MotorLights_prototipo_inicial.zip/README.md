# MotorLights — prototipo inicial

Este es un punto de partida en Flutter para Android y, más adelante, iOS.

## Qué incluye
- Pantalla oscura con detalles verdes.
- Perfil inicial: Yamaha YBR 125 SS, año 2012.
- Inicio/pausa de recorrido con GPS mientras la pantalla está activa.
- Distancia del viaje y distancia acumulada durante esta instalación.
- Estimación orientativa de gasolina y costo configurable.

## Qué NO está terminado
- No es todavía una aplicación lista para publicar.
- El kilometraje no se conserva al cerrar la aplicación.
- El GPS en segundo plano y la ventana flotante de Android aún no están implementados.
- El precio de gasolina no se consulta automáticamente: se introduce manualmente.
- El rendimiento inicial de 35 km/l es solo un valor ilustrativo editable, no una especificación confirmada de la YBR 125 SS 2012.
- La base de datos de consumos por marca/modelo/año todavía debe crearse y verificarse.

## Cómo abrirlo
1. Instala Flutter y Android Studio en un computador.
2. Descomprime el proyecto.
3. En la carpeta del proyecto ejecuta `flutter create .` para generar los archivos de plataforma faltantes.
4. Ejecuta `flutter pub get`.
5. Conecta un teléfono Android con depuración USB y ejecuta `flutter run`.

Para compilar un APK de prueba: `flutter build apk --debug`.

El GPS debe probarse al aire libre y con el teléfono asegurado; no manipules la aplicación mientras conduces.
