import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

void main() => runApp(const MotorLightsApp());

class MotorLightsApp extends StatelessWidget {
  const MotorLightsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MotorLights',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF050807),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF39FF78),
          secondary: Color(0xFF39FF78),
          surface: Color(0xFF101914),
        ),
        useMaterial3: true,
      ),
      home: const DashboardPage(),
    );
  }
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  StreamSubscription<Position>? _subscription;
  Position? _last;
  double _tripKm = 0;
  double _totalKm = 0;
  double _speedKmh = 0;
  bool _tracking = false;
  String _status = 'GPS detenido';
  // Valor inicial ilustrativo. Debe verificarse para la versión y estado reales.
  double _kmPerLiter = 35;
  double _pricePerLiter = 0;

  double get _liters => _tripKm / _kmPerLiter;
  double get _cost => _liters * _pricePerLiter;

  Future<void> _startTracking() async {
    bool service = await Geolocator.isLocationServiceEnabled();
    if (!service) {
      setState(() => _status = 'Activa el GPS del teléfono');
      return;
    }
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      setState(() => _status = 'Permiso de ubicación no concedido');
      return;
    }
    await _subscription?.cancel();
    const settings = LocationSettings(
      accuracy: LocationAccuracy.best,
      distanceFilter: 5,
    );
    setState(() {
      _last = null;
      _tracking = true;
      _status = 'Registrando recorrido';
    });
    _subscription = Geolocator.getPositionStream(locationSettings: settings)
        .listen((position) {
      if (!mounted) return;
      final previous = _last;
      if (previous != null) {
        final meters = Geolocator.distanceBetween(
          previous.latitude, previous.longitude,
          position.latitude, position.longitude,
        );
        // Descarta saltos GPS grandes y lecturas con mala precisión.
        if (position.accuracy <= 35 && meters >= 2 && meters < 250) {
          setState(() {
            _tripKm += meters / 1000;
            _totalKm += meters / 1000;
          });
        }
      }
      setState(() {
        _last = position;
        _speedKmh = (position.speed.isFinite && position.speed > 0)
            ? position.speed * 3.6 : 0;
      });
    }, onError: (_) {
      if (mounted) setState(() => _status = 'Error leyendo el GPS');
    });
  }

  Future<void> _stopTracking() async {
    await _subscription?.cancel();
    _subscription = null;
    setState(() {
      _tracking = false;
      _speedKmh = 0;
      _status = 'Recorrido pausado';
      _last = null;
    });
  }

  void _editEstimates() {
    final km = TextEditingController(text: _kmPerLiter.toStringAsFixed(0));
    final price = TextEditingController(text: _pricePerLiter.toStringAsFixed(0));
    showDialog(context: context, builder: (context) => AlertDialog(
      backgroundColor: const Color(0xFF101914),
      title: const Text('Ajustar estimaciones'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: km, keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Kilómetros por litro (aprox.)')),
        TextField(controller: price, keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Precio por litro en COP')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
        FilledButton(onPressed: () {
          final a = double.tryParse(km.text);
          final b = double.tryParse(price.text);
          if (a != null && a > 0 && b != null && b >= 0) {
            setState(() { _kmPerLiter = a; _pricePerLiter = b; });
          }
          Navigator.pop(context);
        }, child: const Text('Guardar')),
      ],
    ));
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }

  Widget _metric(String label, String value, String unit, IconData icon) =>
      Expanded(child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFF101914),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFF21452E)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: const Color(0xFF39FF78), size: 22),
          const SizedBox(height: 12),
          Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(
            color: Color(0xFF39FF78), fontSize: 25, fontWeight: FontWeight.bold)),
          Text(unit, style: const TextStyle(color: Colors.white54, fontSize: 11)),
        ]),
      ));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('MOTORLIGHTS',
          style: TextStyle(letterSpacing: 2, fontWeight: FontWeight.w900)),
        actions: [IconButton(onPressed: _editEstimates, icon: const Icon(Icons.tune))],
      ),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        const Text('MI MOTOCICLETA', style: TextStyle(color: Colors.white60, letterSpacing: 1.5)),
        const SizedBox(height: 6),
        const Text('Yamaha YBR 125 SS · 2012',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF13291B), Color(0xFF0B110D)]),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: const Color(0xFF28633A)),
          ),
          child: Column(children: [
            const Text('VELOCIDAD GPS', style: TextStyle(color: Colors.white60, letterSpacing: 2)),
            const SizedBox(height: 4),
            Text(_speedKmh.toStringAsFixed(0),
              style: const TextStyle(color: Color(0xFF39FF78), fontSize: 72,
                fontWeight: FontWeight.w900, height: 1.1)),
            const Text('km/h', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 14),
            Text(_status, style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, child: FilledButton.icon(
              onPressed: _tracking ? _stopTracking : _startTracking,
              icon: Icon(_tracking ? Icons.pause : Icons.play_arrow),
              label: Text(_tracking ? 'PAUSAR RECORRIDO' : 'INICIAR RECORRIDO'),
            )),
          ]),
        ),
        const SizedBox(height: 16),
        Row(children: [
          _metric('ESTE VIAJE', _tripKm.toStringAsFixed(1), 'kilómetros', Icons.route),
          const SizedBox(width: 12),
          _metric('KILOMETRAJE', _totalKm.toStringAsFixed(1), 'km registrados aquí', Icons.speed),
        ]),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: const Color(0xFF101914),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFF21452E))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('GASOLINA Y GASTO ESTIMADO',
              style: TextStyle(color: Color(0xFF39FF78), fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Text('${_liters.toStringAsFixed(2)} litros aprox.',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            Text(_pricePerLiter > 0
              ? '\$ ${_cost.toStringAsFixed(0)} COP aprox.'
              : 'Añade el precio por litro para calcular el costo en pesos.',
              style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 8),
            Text('Cálculo orientativo: ${_kmPerLiter.toStringAsFixed(0)} km/l.',
              style: const TextStyle(color: Colors.white54, fontSize: 12)),
            const Text('El consumo real puede variar por tráfico, carga y estado del motor.',
              style: TextStyle(color: Colors.white54, fontSize: 12)),
          ]),
        ),
        const SizedBox(height: 14),
        OutlinedButton.icon(onPressed: _editEstimates,
          icon: const Icon(Icons.local_gas_station), label: const Text('Configurar consumo y precio')),
        const SizedBox(height: 8),
        const Text('Prototipo inicial: el seguimiento funciona mientras esta pantalla permanece activa. '
          'El registro en segundo plano, la ventana flotante y la base de datos de modelos se añadirán '
          'en las siguientes etapas.',
          style: TextStyle(color: Colors.white38, fontSize: 11)),
      ]),
    );
  }
}
